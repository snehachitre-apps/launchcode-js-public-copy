const scorer = require('./scrabble-scorer');

scorer.runProgram();