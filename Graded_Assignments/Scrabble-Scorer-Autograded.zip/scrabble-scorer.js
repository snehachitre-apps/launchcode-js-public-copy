// This assignment is inspired by a problem on Exercism (https://exercism.org/tracks/javascript/exercises/etl) that demonstrates Extract-Transform-Load using Scrabble's scoring system. 

const input = require("readline-sync");

const oldPointStructure = {
  1: ['A', 'E', 'I', 'O', 'U', 'L', 'N', 'R', 'S', 'T'],
  2: ['D', 'G'],
  3: ['B', 'C', 'M', 'P'],
  4: ['F', 'H', 'V', 'W', 'Y'],
  5: ['K'],
  8: ['J', 'X'],
  10: ['Q', 'Z']
};


function oldScrabbleScorer(word) {
  word = word.toUpperCase();
  let letterPoints = "";

  for (let i = 0; i < word.length; i++) {

    for (const pointValue in oldPointStructure) {

      if (oldPointStructure[pointValue].includes(word[i])) {
        letterPoints += `Points for '${word[i]}': ${pointValue}\n`
      }

    }
  }
  return letterPoints;
}

// your job is to finish writing these functions and variables that we've named //
// don't change the names or your program won't work as expected. //

function initialPrompt() {
  console.log("Let's play some scrabble!");
  let userWord = input.question("\nEnter a word to score: ");
  return userWord;
};

let simpleScore = function(word) {
  // word = word.toUpperCase(); // since i am calculating the score based on length i did not see the need to comvert to lower or upper case.
  
  //accomodating for bonus mission that includes space. Counting number of spaces in input string and deducting the points for spaces from total length. 
  if (word.indexOf(' ') !== -1) {
    let spacesCount = word.split(' ').length - 1;
    return word.length - spacesCount;
  }
  else
    return word.length;
};

let vowelBonusScore = function(word) {
  word = word.toUpperCase();
  let letterPoints = 0;
  let vowels = ['A', 'E', 'I', 'O', 'U'];
  for (let i = 0; i < word.length; i++) {
    //accomodating for bonus mission that includes space
    if (word[i] == ' ')
      letterPoints += 0;
    else if (vowels.includes(word[i]))
      letterPoints += 3;
    else
      letterPoints += 1;
  }
  return letterPoints;
};

let scrabbleScore = function(word) {
  word = word.toLowerCase();
  let letterPoints = 0;

  for (let i = 0; i < word.length; i++) {

    letterPoints += newPointStructure[word[i]];

  }

  return letterPoints;
};


let simpleScoreObj = {
  'name': 'Simple Score',
  'description': 'Each letter is worth 1 point.',
  'scoringFunction': simpleScore
};
let bonusVowelsObj = {
  'name': 'Bonus Vowels',
  'description': 'Vowels are 3 pts, consonants are 1 pt.',
  'scoringFunction': vowelBonusScore
};
let scrabbleObj = {
  'name': 'Scrabble',
  'description': 'The traditional scoring algorithm.',
  'scoringFunction': scrabbleScore
};

const scoringAlgorithms = [simpleScoreObj, bonusVowelsObj, scrabbleObj];

function scorerPrompt() {

  console.log("\nWhich scoring algorithm would you like to use?");
  for (let i = 0; i < scoringAlgorithms.length; i++) {
    console.log(`${i} - ${scoringAlgorithms[i].name}: ${scoringAlgorithms[i].description}`)
  }
  algoChoice = Number(input.question("\nEnter 0, 1 or 2: "));

  while ((algoChoice < 0) || (algoChoice > 2)) {
    algoChoice = Number(input.question("Please enter valid choice number (0, 1 or 2): "));
  }
  /// CODE YOUR SOLUTION TO PART B here ///

  return scoringAlgorithms[algoChoice];

}

function transform(oldPointStructure){

//IMPORTANT: npm tests expect the new structire without blank space. It is passing with line 122.  
// let newStructure = {};
//IMPORTANT: npm tests failing if i add code for the bonus mission to accomodate blank space
let newStructure = {
  ' ': 0
};
  
for (key in oldPointStructure) {
  for (let i = 0; i < oldPointStructure[key].length; i++) {
    // for each key value pair array, loop and assign the value /letters as key and corresponding key as value in new structure. 
    newStructure[oldPointStructure[key][i].toLowerCase()] = Number(key);
  }
}

return newStructure;
};

let newPointStructure = transform(oldPointStructure);
//testing how  new point structure looks
// console.log(newPointStructure);


function runProgram() {
  //Take the /input string from user. it can include spaces, or not. 
  let userWord = initialPrompt();
  
  //ask user to choose scoring algorithm. 
  let chosenAlgorithm = scorerPrompt();
  //display result for that scoring algorithm
  console.log(`Score for '${userWord}': ${chosenAlgorithm.scoringFunction(userWord)}`);

}

// Don't write any code below this line //
// And don't change these or your program will not run as expected //
module.exports = {
  initialPrompt: initialPrompt,
  transform: transform,
  oldPointStructure: oldPointStructure,
  simpleScore: simpleScore,
  vowelBonusScore: vowelBonusScore,
  scrabbleScore: scrabbleScore,
  scoringAlgorithms: scoringAlgorithms,
  newPointStructure: newPointStructure,
  runProgram: runProgram,
  scorerPrompt: scorerPrompt
};

